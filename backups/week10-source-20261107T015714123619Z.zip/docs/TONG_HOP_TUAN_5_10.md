# Theo dõi hoàn thiện tuần 5–10

Cập nhật **07/11/2026**. Theo yêu cầu: làm lần lượt các tuần còn lại, ghi `.md` sau mỗi tuần và **chưa kiểm thử**. Tuần 8 → 9 → 10 đã được bổ sung nối tiếp trong workspace. Mốc nghiệm thu vẫn **0/6**.

| Tuần | Phần đã bổ sung | Note chi tiết | Trạng thái xác minh |
| --- | --- | --- | --- |
| 5 | MFA, phiên/token, hardening, UI | [Tuần 5](TUAN_5_TRIEN_KHAI.md) | Chưa build/test/áp dụng mã mới |
| 6 | OpenLDAP LDAPS, federation, nhóm/role, đồng bộ | [Tuần 6](TUAN_6_TRIEN_KHAI.md) | Chưa build/test/áp dụng mã mới |
| 7 | Join/Change/Leave, yêu cầu/duyệt quyền, rà soát | [Tuần 7](TUAN_7_TRIEN_KHAI.md) | Chưa build/test/áp dụng mã mới |
| 8 | PostgreSQL Audit, outbox, Admin Events, monitoring | [Tuần 8](TUAN_8_TRIEN_KHAI.md) | Chưa build/test/áp dụng |
| 9 | Python baseline, nhãn, metrics, UI và nguồn test | [Tuần 9](TUAN_9_TRIEN_KHAI.md) | Chưa chạy detector/test, chưa có số đo |
| 10 | Runner, backup/recovery, report/slide, demo plan | [Tuần 10](TUAN_10_TRIEN_KHAI.md) | Tài liệu nháp; chưa nghiệm thu/demo thật |

## Hồ sơ bàn giao

- [Báo cáo Word](ban_giao/BaoCaoTongHop_IAM_Tuan5-10_DRAFT.docx) — bản thảo kỹ thuật, không có số liệu bịa.
- [PowerPoint 15 slide](ban_giao/BaoVe_IAM_Tuan5-10_DRAFT.pptx) — cần bổ sung kết quả thực nghiệm sau khi chạy.
- [Báo cáo Markdown](BAO_CAO_TONG_HOP.md) và [nội dung slide](SLIDE_BAO_VE.md) là nguồn để tái sinh tài liệu.
- [Kiến trúc và các luồng](KIEN_TRUC_VA_LUONG_HE_THONG.md).
- [Hướng dẫn vận hành và khôi phục](BAN_GIAO_VA_VAN_HANH.md).
- [Kịch bản demo/video](KICH_BAN_DEMO_VA_VIDEO.md).
- [Checklist bảo mật tuần 9](TUAN_9_NGHIEM_THU.md), kết hợp checklist tuần 5/6/7 và note tuần 8.

## Công việc còn chờ theo yêu cầu chưa kiểm thử

Build/cài dependency mới; áp dụng migration/config; chạy hệ thống và detector; test tích hợp/bảo mật/restore; thu dataset và chỉ số thật; chụp minh chứng; quay video; diễn tập bảo vệ; chốt release và push Git. Các file Word/PowerPoint đã được tạo nhưng chưa mở/render để xác nhận trình bày.

Source ZIP có thể tái tạo bằng `python scripts/package_week10.py`, nằm trong thư mục ignored `backups`. Không chứa credential/runtime và không thay thế backup dữ liệu. Không dùng kết quả test lịch sử trước tuần 5 để xác nhận source hiện tại.
